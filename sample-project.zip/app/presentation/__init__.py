# Presentation init
