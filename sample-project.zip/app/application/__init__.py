# Application init
